@echo off
setlocal enabledelayedexpansion

echo ==========================================================
echo   AntiGQS Revit Add-in Smart Uninstaller
echo ==========================================================
echo.
echo Detecting installed AntiGQS instances and removing...
echo.

set "UNINSTALLED_VERSIONS="
set "FOUND_INSTANCES=0"

for %%V in (2022 2023 2024 2025 2026 2027) do (
    set "REVIT_YEAR=%%V"
    set "TARGET_DIR=%AppData%\Autodesk\Revit\Addins\!REVIT_YEAR!"
    
    set "FOUND_THIS_YEAR=0"
    
    if exist "!TARGET_DIR!\AntiGQS.addin" (
        set "FOUND_THIS_YEAR=1"
        del "!TARGET_DIR!\AntiGQS.addin"
    )
    
    if exist "!TARGET_DIR!\AntiGQS" (
        set "FOUND_THIS_YEAR=1"
        rd /s /q "!TARGET_DIR!\AntiGQS"
    )
    
    if !FOUND_THIS_YEAR! EQU 1 (
        echo [-] Removed AntiGQS from Revit !REVIT_YEAR!.
        set "UNINSTALLED_VERSIONS=!UNINSTALLED_VERSIONS! %%V"
        set "FOUND_INSTANCES=1"
    )
)

echo.
if !FOUND_INSTANCES! EQU 1 (
    echo ==========================================================
    echo   SUCCESS: Uninstalled AntiGQS from: !UNINSTALLED_VERSIONS!
    echo ==========================================================
) else (
    echo ==========================================================
    echo   INFO: No AntiGQS installations detected.
    echo ==========================================================
)

echo.
pause
